#include "polynomial.h"
#include "uno.h"
#include "texteditor.h"
#include <iostream>
using namespace std;

int main() {
    Polynomial p1;
    p1.insertTerm(3, 4);
    p1.insertTerm(2, 2);
    p1.insertTerm(-1, 1);
    p1.insertTerm(5, 0);

    Polynomial p2;
    p2.insertTerm(1, 4);
    p2.insertTerm(1, 0);

    Polynomial sum = p1.add(p2);
    Polynomial p3;
    p3.insertTerm(2, 1);
    Polynomial prod = sum.multiply(p3);
    Polynomial deriv = p1.derivative();

    cout << "p1.toString(): " << p1.toString() << endl;
    cout << "sum.toString(): " << sum.toString() << endl;
    cout << "prod.toString(): " << prod.toString() << endl;
    cout << "deriv.toString(): " << deriv.toString() << endl;

    //task2
      TextEditor ed;

    ed.insertChar('a');
    cout << "After insert 'a': " << ed.getTextWithCursor() << endl;

    ed.insertChar('b');
    cout << "After insert 'b': " << ed.getTextWithCursor() << endl;

    ed.moveLeft();
    cout << "After move left: " << ed.getTextWithCursor() << endl;

    ed.insertChar('c');
    cout << "After insert 'c': " << ed.getTextWithCursor() << endl;

    ed.deleteChar();
    cout << "After delete: " << ed.getTextWithCursor() << endl;

    ed.moveLeft();
    ed.moveLeft();
    cout << "After move left twice: " << ed.getTextWithCursor() << endl;

    ed.moveRight();
    ed.moveRight();
    cout << "After move right twice: " << ed.getTextWithCursor() << endl;

    // task3
    UNOGame game(2);
    game.initialize();

    cout << game.getState() << endl;
    game.playTurn();
    cout << game.getState() << endl;
    game.playTurn();
    cout << game.getState() << endl;
    game.playTurn();
    cout << game.getState() << endl;
}
