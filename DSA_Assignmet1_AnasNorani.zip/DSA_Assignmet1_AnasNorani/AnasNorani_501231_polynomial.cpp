#include "polynomial.h"
#include <iostream>
#include <sstream>
#include <cmath>
#include <unordered_map>
using namespace std;

// Node structure for linked list
struct Term {
    int coeff;
    int exp;
    Term* next;
    Term(int c, int e) : coeff(c), exp(e), next(nullptr) {}
};

// Internal linked list holder
class PolyData {
public:
    Term* head;
    PolyData() : head(nullptr) {}
    ~PolyData() {
        while (head) {
            Term* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

// Global map: associate each Polynomial object with its linked list
static unordered_map<const Polynomial*, PolyData*> polyList;

// Helper to get or create linked list for a Polynomial
static PolyData* ensurePoly(const Polynomial* p) {
    if (!polyList.count(p))
        polyList[p] = new PolyData();
    return polyList[p];
}

// --------------------------------------------------------------
// Insert a term into the polynomial
void Polynomial::insertTerm(int coefficient, int exponent) {
    if (coefficient == 0) return;

    Term*& head = ensurePoly(this)->head;
    Term* newTerm = new Term(coefficient, exponent);

    // Insert in descending order
    if (!head || exponent > head->exp) {
        newTerm->next = head;
        head = newTerm;
        return;
    }

    Term* curr = head;
    Term* prev = nullptr;

    while (curr && curr->exp > exponent) {
        prev = curr;
        curr = curr->next;
    }

    // Merge or insert new term
    if (curr && curr->exp == exponent) {
        curr->coeff += coefficient;
        if (curr->coeff == 0) { // remove zero coefficient term
            if (prev) prev->next = curr->next;
            else head = curr->next;
            delete curr;
        }
        delete newTerm;
    } else {
        newTerm->next = curr;
        if (prev) prev->next = newTerm;
        else head = newTerm;
    }
}

// --------------------------------------------------------------
// Return polynomial as human-readable string
string Polynomial::toString() const {
    Term* curr = ensurePoly(this)->head;
    if (!curr) return "0";

    ostringstream oss;
    bool first = true;

    while (curr) {
        if (!first)
            oss << (curr->coeff > 0 ? " + " : " - ");
        else {
            if (curr->coeff < 0) oss << "-";
            first = false;
        }

        int absCoeff = abs(curr->coeff);
        if (curr->exp == 0)
            oss << absCoeff;
        else if (curr->exp == 1)
            oss << (absCoeff == 1 ? "x" : to_string(absCoeff) + "x");
        else
            oss << (absCoeff == 1
                        ? "x^" + to_string(curr->exp)
                        : to_string(absCoeff) + "x^" + to_string(curr->exp));
        curr = curr->next;
    }

    return oss.str();
}

// --------------------------------------------------------------
// Return a new polynomial that is the sum of this and another
Polynomial Polynomial::add(const Polynomial& other) const {
    Polynomial result;
    Term* a = ensurePoly(this)->head;
    Term* b = ensurePoly(&other)->head;

    while (a || b) {
        if (b == nullptr || (a && a->exp > b->exp)) {
            result.insertTerm(a->coeff, a->exp);
            a = a->next;
        } else if (a == nullptr || b->exp > a->exp) {
            result.insertTerm(b->coeff, b->exp);
            b = b->next;
        } else {
            result.insertTerm(a->coeff + b->coeff, a->exp);
            a = a->next;
            b = b->next;
        }
    }
    return result;
}

// --------------------------------------------------------------
// Return a new polynomial that is the product of this and another
Polynomial Polynomial::multiply(const Polynomial& other) const {
    Polynomial result;
    Term* a = ensurePoly(this)->head;
    Term* b = ensurePoly(&other)->head;

    for (Term* p = a; p; p = p->next)
        for (Term* q = b; q; q = q->next)
            result.insertTerm(p->coeff * q->coeff, p->exp + q->exp);

    return result;
}

// --------------------------------------------------------------
// Return a new polynomial that is the derivative of this polynomial
Polynomial Polynomial::derivative() const {
    Polynomial result;
    Term* curr = ensurePoly(this)->head;

    while (curr) {
        if (curr->exp > 0)
            result.insertTerm(curr->coeff * curr->exp, curr->exp - 1);
        curr = curr->next;
    }

    return result;
}
