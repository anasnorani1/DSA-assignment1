#include "texteditor.h"
#include <stack>
#include <string>
#include <unordered_map>
#include <algorithm>
using namespace std;

// Each TextEditor object maintains its own editor state
struct EditorState {
    stack<char> left;   // characters to the left of cursor
    stack<char> right;  // characters to the right of cursor
};

// Global map to link each TextEditor instance to its state
static unordered_map<const TextEditor*, EditorState*> editorMap;

// Helper to retrieve or initialize editor state
static EditorState* ensureEditor(const TextEditor* e) {
    if (!editorMap.count(e))
        editorMap[e] = new EditorState();
    return editorMap[e];
}

// --------------------------------------------------------------
// Insert character at cursor (push to left stack)
void TextEditor::insertChar(char c) {
    ensureEditor(this)->left.push(c);
}

// --------------------------------------------------------------
// Delete character before cursor (pop from left stack)
void TextEditor::deleteChar() {
    EditorState* ed = ensureEditor(this);
    if (!ed->left.empty())
        ed->left.pop();
}

// --------------------------------------------------------------
// Move cursor one position left (move top from left → right)
void TextEditor::moveLeft() {
    EditorState* ed = ensureEditor(this);
    if (!ed->left.empty()) {
        char c = ed->left.top();
        ed->left.pop();
        ed->right.push(c);
    }
}

// --------------------------------------------------------------
// Move cursor one position right (move top from right → left)
void TextEditor::moveRight() {
    EditorState* ed = ensureEditor(this);
    if (!ed->right.empty()) {
        char c = ed->right.top();
        ed->right.pop();
        ed->left.push(c);
    }
}

// --------------------------------------------------------------
// Get full text with '|' showing cursor position
string TextEditor::getTextWithCursor() const {
    EditorState* ed = ensureEditor(this);

    // Extract left side (reverse stack order)
    string leftText;
    stack<char> tempLeft = ed->left;
    while (!tempLeft.empty()) {
        leftText.push_back(tempLeft.top());
        tempLeft.pop();
    }
    reverse(leftText.begin(), leftText.end());

    // Extract right side (keep normal stack order)
    string rightText;
    stack<char> tempRight = ed->right;
    while (!tempRight.empty()) {
        rightText.push_back(tempRight.top());
        tempRight.pop();
    }

    return leftText + "|" + rightText;
}
