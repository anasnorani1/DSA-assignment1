#include "uno.h"
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <random>
#include <sstream>
#include <numeric>       
#include <unordered_map> 

using namespace std;

struct CardStack {
    vector<Card> cards;
    vector<string> texts;
};

struct GameState {
    vector<string> colors = {"Red", "Green", "Blue", "Yellow"};
    CardStack deck;
    vector<CardStack> players;
    CardStack discard;

    int totalPlayers = 0;
    int currentPlayer = 0;
    int direction = 1;
    bool gameOver = false;
    int winnerIndex = -1;
};

static unordered_map<const UNOGame*, GameState*> games;

static GameState* ensureGame(const UNOGame* g) {
    if (!games.count(g)) games[g] = new GameState();
    return games[g];
}

UNOGame::UNOGame(int numPlayers) {
    GameState* gs = ensureGame(this);
    gs->totalPlayers = numPlayers;
    gs->deck.cards.clear();
    gs->deck.texts.clear();
    gs->discard.cards.clear();
    gs->discard.texts.clear();
    gs->players.assign(numPlayers, {});
    gs->currentPlayer = 0;
    gs->direction = 1;
    gs->gameOver = false;
    gs->winnerIndex = -1;
}


void UNOGame::initialize() {
    GameState* gs = ensureGame(this);
    gs->deck.cards.clear();
    gs->deck.texts.clear();

    vector<string> specials = {"Skip", "Reverse", "Draw Two"};

    // Build deck
    for (auto& color : gs->colors) {
        for (int v = 0; v <= 9; v++) {
            gs->deck.cards.emplace_back();
            gs->deck.texts.push_back(color + " " + to_string(v));
        }
        for (auto& sp : specials) {
            gs->deck.cards.emplace_back();
            gs->deck.texts.push_back(color + " " + sp);
        }
    }

    //  random seed
    mt19937 rng(1234);
    vector<int> idx(gs->deck.cards.size());
    iota(idx.begin(), idx.end(), 0);
    shuffle(idx.begin(), idx.end(), rng);

    // Apply shuffled order
    CardStack shuffled;
    for (int i : idx) {
        shuffled.cards.push_back(gs->deck.cards[i]);
        shuffled.texts.push_back(gs->deck.texts[i]);
    }
    gs->deck = shuffled;

    // Deal 7 cards
    int n = gs->totalPlayers;
    gs->players.assign(n, {});
    for (int i = 0; i < 7; i++) {
        for (int p = 0; p < n; p++) {
            if (!gs->deck.cards.empty()) {
                gs->players[p].cards.push_back(gs->deck.cards.back());
                gs->players[p].texts.push_back(gs->deck.texts.back());
                gs->deck.cards.pop_back();
                gs->deck.texts.pop_back();
            }
        }
    }

    // Start discard pile
    if (!gs->deck.cards.empty()) {
        gs->discard.cards.push_back(gs->deck.cards.back());
        gs->discard.texts.push_back(gs->deck.texts.back());
        gs->deck.cards.pop_back();
        gs->deck.texts.pop_back();
    }
}

void UNOGame::playTurn() {
    GameState* gs = ensureGame(this);
    if (gs->gameOver) return;

    int p = gs->currentPlayer;
    auto& hand = gs->players[p];
    string top = gs->discard.texts.back();

    string topColor = top.substr(0, top.find(' '));
    string topValue = top.substr(top.find(' ') + 1);

    bool played = false;
    int idx = -1;
    string chosen = "";

    for (int i = 0; i < (int)hand.texts.size(); i++) {
        string s = hand.texts[i];
        string color = s.substr(0, s.find(' '));
        string value = s.substr(s.find(' ') + 1);
        if (color == topColor || value == topValue) {
            if (!played || value == "Skip" ||
                (value == "Reverse" && chosen != "Skip") ||
                (value == "Draw Two" && chosen != "Skip" && chosen != "Reverse")) {
                played = true;
                idx = i;
                chosen = value;
            }
        }
    }

    if (played) {
        gs->discard.cards.push_back(hand.cards[idx]);
        gs->discard.texts.push_back(hand.texts[idx]);
        hand.cards.erase(hand.cards.begin() + idx);
        hand.texts.erase(hand.texts.begin() + idx);

        if (chosen == "Reverse") {
            gs->direction *= -1;
        } else if (chosen == "Skip") {
            gs->currentPlayer = (gs->currentPlayer + gs->direction + gs->totalPlayers) % gs->totalPlayers;
        } else if (chosen == "Draw Two") {
            int next = (gs->currentPlayer + gs->direction + gs->totalPlayers) % gs->totalPlayers;
            for (int i = 0; i < 2 && !gs->deck.cards.empty(); i++) {
                gs->players[next].cards.push_back(gs->deck.cards.back());
                gs->players[next].texts.push_back(gs->deck.texts.back());
                gs->deck.cards.pop_back();
                gs->deck.texts.pop_back();
            }
        }
    } else {
        // Draw
        if (!gs->deck.cards.empty()) {
            hand.cards.push_back(gs->deck.cards.back());
            hand.texts.push_back(gs->deck.texts.back());
            gs->deck.cards.pop_back();
            gs->deck.texts.pop_back();
        }
    }

    if (hand.cards.empty()) {
        gs->gameOver = true;
        gs->winnerIndex = p;
        return;
    }

    gs->currentPlayer = (gs->currentPlayer + gs->direction + gs->totalPlayers) % gs->totalPlayers;
}

bool UNOGame::isGameOver() const {
    return ensureGame(this)->gameOver;
}

int UNOGame::getWinner() const {
    return ensureGame(this)->winnerIndex;
}

string UNOGame::getState() const {
    GameState* gs = ensureGame(this);
    ostringstream oss;

    string dir = (gs->direction == 1 ? "Clockwise" : "Counter-clockwise");
    string top = gs->discard.texts.empty() ? "None" : gs->discard.texts.back();

    oss << "Player " << gs->currentPlayer
        << "'s turn, Direction: " << dir
        << ", Top: " << top
        << ", Players cards: ";

    for (int i = 0; i < gs->totalPlayers; i++) {
        oss << "P" << i << ":" << gs->players[i].cards.size();
        if (i < gs->totalPlayers - 1) oss << ", ";
    }
    return oss.str();
}
